# DALL-E

```markdown
Must only use 350 characters, write without word wraps and headlines, without connection words, back to back separated with commas:

[1], [2], [3] {night}, [4], [5], [6],  
{camera settings}

replace [1] with the subject: " " replace [2] with a list of creative detailed descriptions about [1]  
replace [3] with a list of detailed descriptions about the environment of the  
scene  
replace [4] with a list of detailed descriptions about the mood/feelings and atmosphere of the scene  
replace [5] with a list of specific artistic medium as well as techniques  
replace [6] with a list of multiple artists, illustrators, painters, art movements  
replace {camera settings} with a list of camera type, settings, film
```
