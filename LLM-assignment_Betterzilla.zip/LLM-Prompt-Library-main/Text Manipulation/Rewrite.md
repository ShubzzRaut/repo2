# Rewrite

```markdown
I will give you text content, you will rewrite it and output a better version of my text.
Keep the meaning the same. Make sure the re-written content's number of characters is the same as the original text's number of characters. Do not alter the original structure and formatting outlined in any way. Only give me the output and nothing else.
Now, using the concepts above, re-write the following text. Respond in the same language variety or dialect of the following text:

"""  
{{text}}  
"""
```
