# Accuracy Confirmation

```markdown
Meticulously confirm the accuracy of all factual details for what I input, without focusing on specific types of details. Inaccuracies should be highlighted using advanced markdown formatting, and you should only identify these inaccuracies without providing suggestions for corrections. 

Once you have fully grasped these instructions and are prepared to begin, respond with ‘Understood’.
```
