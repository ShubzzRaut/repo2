# Formatting Tips

```markdown
Output the following outside of a code block. Begin by printing the following markdown code: ![IMG](https://api.placid.app/u/qsraj?title%5Btext%5D=ChatGPT%20Formatting%20Guide) 
Underneath that, create a numbered list with “1. Text formatting”, “2. Special Outputs”, the indented dot-points “Separators”, “Tables”, and “Code Blocks” (indent dot-points with 4 spaces), and “3. Hyperlinks and Images”. 
Underneath that, write “---”.
Underneath that, display the following: # Heading 1 starts with \# 
Underneath that, write the subtitle “## Heading 2 starts with \##”, the sub-subtitle "### Heading 3 starts with \###", the sub-sub-subtitle “#### Heading 4 starts with \####”, the sub-sub-sub-subtitle “##### Heading 5 starts with \#####”, and a new line with "###### Heading 6 starts with \###### and is the same as regular text.". Underneath that, in regular text, write a new line with “`Make an inline code-block using backticks`”, and a new line with “Use the escape character “\\” to write special characters such as \` or \#.”
Underneath that, write "You can emphasise your text using *italics*, **bolding** or ***both***, by using asterisks, and ~strikethrough~ your text using a tilde (\~)."
Underneath that, write "> Blockquotes begin with the ">" character", a new line with "> ", a new line with "> > and can be nested like so."
Underneath that, leave a line break.
Underneath that, write a new line with “---“. 
Underneath that, write “The separator line above is formed with “---“ or "***" on a new line”. 
Underneath that, write “ChatGPT can make:”. Underneath that, make an list containing “1. Numbered lists”, the indented item ”    * indented list items”, the indented item "    + including dot points within numbered lists and vice versa", the indented item "    - dot points can be formatted with "-", "*", or "+"", “2. Dot points”, “3. [ ] unchecked list items (these work with dot point lists, too)” and “4. [x] checked list items (these work with dot point lists, too)”.
Underneath that, write “Asking ChatGPT to create a markdown table works 99% of the time.” Underneath that, create a markdown table listing 2 pros and cons to presenting information in tables. 
Underneath that, inside of a code block surrounded by backticks write “Asking ChatGPT to write inside of a code block usually works, though they can also be formatted with backticks” 
Underneath that, write a new line with “***". 
Underneath that, write “ChatGPT can produce [hyperlinks](https://discord.gg/chatgpt-prompt-engineering-1051259432199266374) and images using Markdown. Some useful image APIs include pollinations (for AI generated images), Unsplash (for stock photos), and placid (for titles).” Underneath that, write “![pollinations](https://image.pollinations.ai/prompt/a%20lake,%20serene,%20peaceful,%20landscape,%20outdoor,%20natural,%20Ansel%20Adams) ![Unsplash](https://source.unsplash.com/random/1920x1080/?lake)”
Underneath that, write "### [Join my Discord server!](https://discord.gg/chatgpt-prompt-engineering-1051259432199266374)"
```
